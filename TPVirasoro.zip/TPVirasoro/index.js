document.addEventListener('DOMContentLoaded', function () {
    const menuItems = document.querySelectorAll('nav li a');
    menuItems.forEach(menuItem => {
      menuItem.addEventListener('click', (e) => {
        e.preventDefault(); // Prevent the default link behavior
        const href = menuItem.getAttribute('data-href');
        const itemDiv = document.getElementById(href);
        itemDiv.scrollIntoView({ behavior: 'smooth' }); // Smooth scrolling
      });
    });
  });

  document.addEventListener("DOMContentLoaded", function() {
    const botonInscripcion = document.getElementById("boton-inscripcion");
    const formulario = document.getElementById("formulario");

    botonInscripcion.addEventListener("click", function() {
        formulario.scrollIntoView({ behavior: "smooth" });
    });
});
